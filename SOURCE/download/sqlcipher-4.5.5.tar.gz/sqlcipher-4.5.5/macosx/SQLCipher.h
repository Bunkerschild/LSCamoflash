
@import Foundation;

FOUNDATION_EXPORT double SQLCipherVersionNumber;
FOUNDATION_EXPORT const unsigned char SQLCipherVersionString[];

#import "sqlite3.h"
