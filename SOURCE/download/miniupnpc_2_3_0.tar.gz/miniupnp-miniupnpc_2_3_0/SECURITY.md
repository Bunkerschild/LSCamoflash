# Security Policy

## Supported Versions

| Package | Version | Supported          |
| ------- | ------- | ------------------ |
| miniupnpd | 2.3.x | :white_check_mark: |
| miniupnpd | < 2.3 | :x:                |
| miniupnpc | 2.2.x | :white_check_mark: |
| miniupnpc | < 2.2 | :x:                |

## Reporting a Vulnerability

Contact miniupnp@free.fr ([GPG Key](https://miniupnp.tuxfamily.org/A31ACAAF.asc))
