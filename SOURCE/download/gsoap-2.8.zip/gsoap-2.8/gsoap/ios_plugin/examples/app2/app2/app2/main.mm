//
//  main.m
//  

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#include "../../GeoIPServiceSoap.nsmap"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
