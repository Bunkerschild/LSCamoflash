This directory contains a "one-liner" service: gSOAP Web client applications
that are only one line long (not counting the usual #includes).

The oneliners are small, but they can do a number of useful things. The
complete list of oneliners is:

samples/gmt       return current time in GMT
samples/hello     "Hello World!"
samples/roll      rolling a die
